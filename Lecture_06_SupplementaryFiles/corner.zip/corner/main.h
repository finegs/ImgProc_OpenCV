#include <stdio.h>
#include <stdlib.h>

#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>

using namespace cv;
using namespace std;

void cornerDetector(Mat input);